﻿using System.Web.Mvc;

namespace LeagueSportsManager.Areas.HelpPage.Controllers
{
    public class _Page_Areas_Sport_Views_TableTennis_cshtmlController : Controller
    {
        public ActionResult TableTennis()
        {
            throw new System.NotImplementedException();
        }
    }
}